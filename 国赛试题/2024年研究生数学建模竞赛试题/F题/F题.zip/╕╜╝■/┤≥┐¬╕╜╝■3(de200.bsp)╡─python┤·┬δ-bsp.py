from jplephem.spk import SPK
import numpy as np

kernel = SPK.open("F://2024年研究生建模竞赛命题会//X射线脉冲星光子到达时间研究//附件//附件3-de200.bsp")

jd= np.array([2457061.5,2457062.5,2457063.5,2457064.5])
position = kernel[0,4].compute(jd)

print(position)
